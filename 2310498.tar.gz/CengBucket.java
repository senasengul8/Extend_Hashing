import java.util.ArrayList;

public class CengBucket {

	public int capacity;
	public int bits;
	public int pointing;
	public int npointing;
	public ArrayList<CengPoke> pokes;
	// GUI-Based Methods
	// These methods are required by GUI to work properly.

	public CengBucket(int capacity, int bits)
	{
		this.capacity = capacity;
		this.bits = bits;

		notifyNoOnePoints();
		pokes = new ArrayList<CengPoke>(this.capacity);
	}

	public void notifyNoOnePoints()
	{
		pointing = -1;
		npointing = 0;
	}

	public void notify(int index)
	{
		// hashRow at index is now pointing me
		if (pointing == -1 || pointing > index)
		{
			pointing = index;
		}
		npointing++;
	}

	public Boolean addSucceeds(CengPoke poke)
	{
		if (capacity == pokes.size())
		{
			return false;
		}
		// else if (capacity < pokes.size())
		//{
		//     System.out.println("++++++++++++++++++++++error+++++++++++++++++++++++++++++++++++++");
		//  return false;
		//}

		pokes.add(poke);
		return true;
	}

	public Boolean isAvail()
	{
		return capacity > pokes.size();
	}

	public int pokeCount()
	{
		// DID: Return the coin count in the bucket.
		return pokes.size();
	}

	public CengPoke pokeAtIndex(int index)
	{
		// DID: Return the corresponding coin at the index.
		return pokes.get(index);
	}

	public int getHashPrefix()
	{
		// DID: Return hash prefix length.
		return bits;
	}

	public Boolean isVisited()
	{
		// SKIP: Return whether the bucket is found while searching.
		return false;
	}

}
